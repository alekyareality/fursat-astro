# One-time setup for the React islands (/menu and the /party 3D stage)

npm i @astrojs/react react@19 react-dom@19 @types/react @types/react-dom motion three @react-three/fiber @types/three tailwindcss @tailwindcss/vite

astro.config.mjs:
  import react from '@astrojs/react';
  import tailwindcss from '@tailwindcss/vite';
  export default defineConfig({ integrations: [react()], vite: { plugins: [tailwindcss()] } });

tsconfig.json compilerOptions: "jsx": "react-jsx"

- Tailwind loads only on /menu (no preflight).
- The 3D chunk (~246 KB gzip) loads only on /party, only when the estimate section scrolls into view,
  and never on reduced-motion, save-data, <=2-core / <=2 GB devices or without WebGL. Those users see the webp poster.
- Page script events: party.js dispatches `fursat:plan` (lid lifts) and `fursat:pkg` (lid hops).
